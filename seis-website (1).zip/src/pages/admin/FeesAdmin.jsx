import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useSite } from '../../lib/SiteContext'
import AdminLayout from '../../components/admin/AdminLayout'
import toast from 'react-hot-toast'

export default function FeesAdmin() {
  const { refetch } = useSite()

  const [bank, setBank] = useState({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    supabase.from('bank_details').select('*').single().then(({ data }) => { if (data) setBank(data) })
  }, [])

  const save = async () => {
    setSaving(true)
    const { error } = await supabase.from('bank_details').update(bank).eq('id', 1)
    if (error) toast.error(error.message)
    else toast.success('Bank details saved')
    setSaving(false)
  }

  const Field = ({ label, field }) => (
    <div className="mb-3">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input value={bank[field] || ''} onChange={e => setBank({...bank, [field]: e.target.value})} className="admin-input" />
    </div>
  )

  const content = (
    <div className="admin-card max-w-lg">
      <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Bank Transfer Details</h3>
      <Field label="Bank Name" field="bank_name" />
      <Field label="Account Name" field="account_name" />
      <Field label="Account Number" field="account_number" />
      <Field label="SWIFT / IBAN" field="swift_iban" />
      <Field label="Reference Format" field="reference_format" />
      <div className="mb-4">
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input type="checkbox" checked={bank.is_published || false} onChange={e => setBank({...bank, is_published: e.target.checked})} />
          Show bank details on public site
        </label>
      </div>
      <button onClick={save} disabled={saving} className="admin-btn">{saving ? 'Saving...' : 'Save Bank Details'}</button>
    </div>
  )

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Fees</h1>
      <p className="text-sm text-gray-500 mb-6">Manage entry fee and bank details</p>
      {content}
    </AdminLayout>
  )
}
