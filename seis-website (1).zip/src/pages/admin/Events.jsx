import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useSite } from '../../lib/SiteContext'
import AdminLayout from '../../components/admin/AdminLayout'
import toast from 'react-hot-toast'

const emptyEvent = { event_number: 0, gender: 'girls', event_name: '', distance: null, stroke: 'freestyle', age_group: '11+', format: 'prelims', day: 1, session: 'morning', sort_order: 0, is_break: false, break_label: '' }

export default function Events() {
  const { refetch } = useSite()
  const [events, setEvents] = useState([])
  const [filter, setFilter] = useState({ day: '', session: '' })
  const [editing, setEditing] = useState(null)
  const [newEvent, setNewEvent] = useState(null)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    const { data } = await supabase.from('events').select('*').order('day').order('sort_order')
    setEvents(data || [])
  }
  useEffect(() => { load() }, [])

  let filtered = events
  if (filter.day) filtered = filtered.filter(e => e.day === parseInt(filter.day))
  if (filter.session) filtered = filtered.filter(e => e.session === filter.session)

  const saveEvent = async (evt) => {
    setSaving(true)
    const { id, ...data } = evt
    if (id) {
      const { error } = await supabase.from('events').update(data).eq('id', id)
      if (error) toast.error(error.message)
      else { toast.success('Event updated'); setEditing(null); load() }
    } else {
      const { error } = await supabase.from('events').insert(data)
      if (error) toast.error(error.message)
      else { toast.success('Event added'); setNewEvent(null); load() }
    }
    setSaving(false)
  }

  const deleteEvent = async (id) => {
    if (!confirm('Delete this event?')) return
    const { error } = await supabase.from('events').delete().eq('id', id)
    if (error) toast.error(error.message)
    else { toast.success('Event deleted'); load() }
  }

  const addBreak = () => {
    setNewEvent({
      event_number: 0, gender: 'mixed', event_name: 'Break', distance: null,
      stroke: null, age_group: '11+', format: 'timed_final',
      day: filter.day ? parseInt(filter.day) : 1,
      session: filter.session || 'morning',
      sort_order: events.length + 1, is_break: true, break_label: 'Break'
    })
  }

  const EventForm = ({ evt, onSave, onCancel }) => {
    const [f, setF] = useState(evt)
    return (
      <tr className="bg-blue-50">
        <td className="p-2"><input type="number" value={f.event_number} onChange={e => setF({...f, event_number: parseInt(e.target.value) || 0})} className="admin-input w-16" /></td>
        <td className="p-2">
          <select value={f.gender} onChange={e => setF({...f, gender: e.target.value})} className="admin-input w-20">
            <option value="girls">Girls</option><option value="boys">Boys</option><option value="mixed">Mixed</option>
          </select>
        </td>
        <td className="p-2">
          {f.is_break ? (
            <input value={f.break_label || ''} onChange={e => setF({...f, break_label: e.target.value, event_name: e.target.value})} placeholder="Break label..." className="admin-input" />
          ) : (
            <input value={f.event_name} onChange={e => setF({...f, event_name: e.target.value})} className="admin-input" />
          )}
        </td>
        <td className="p-2"><select value={f.age_group} onChange={e => setF({...f, age_group: e.target.value})} className="admin-input w-20"><option value="8u">8u</option><option value="9-10">9-10</option><option value="11+">11+</option></select></td>
        <td className="p-2"><select value={f.format} onChange={e => setF({...f, format: e.target.value})} className="admin-input w-28"><option value="timed_final">Timed Final</option><option value="prelims">Prelims</option><option value="finals">Finals</option></select></td>
        <td className="p-2"><select value={f.day} onChange={e => setF({...f, day: parseInt(e.target.value)})} className="admin-input w-14"><option value={1}>1</option><option value={2}>2</option></select></td>
        <td className="p-2"><select value={f.session} onChange={e => setF({...f, session: e.target.value})} className="admin-input w-24"><option value="morning">AM</option><option value="evening">PM</option></select></td>
        <td className="p-2">
          <div className="flex gap-1">
            <button onClick={() => onSave(f)} disabled={saving} className="admin-btn text-xs">{saving ? '...' : 'Save'}</button>
            <button onClick={onCancel} className="admin-btn-outline text-xs">Cancel</button>
          </div>
        </td>
      </tr>
    )
  }

  const eventCount = events.filter(e => !e.is_break).length
  const breakCount = events.filter(e => e.is_break).length

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Events</h1>
      <p className="text-sm text-gray-500 mb-4">{eventCount} events + {breakCount} breaks across {new Set(events.map(e => e.day)).size} days</p>

      <div className="flex gap-3 mb-4 flex-wrap">
        <select value={filter.day} onChange={e => setFilter({...filter, day: e.target.value})} className="admin-input max-w-[150px]"><option value="">All Days</option><option value="1">Day 1</option><option value="2">Day 2</option></select>
        <select value={filter.session} onChange={e => setFilter({...filter, session: e.target.value})} className="admin-input max-w-[150px]"><option value="">All Sessions</option><option value="morning">Morning</option><option value="evening">Evening</option></select>
        <button onClick={() => setNewEvent({...emptyEvent, sort_order: events.length + 1})} className="admin-btn">+ Add Event</button>
        <button onClick={addBreak} className="admin-btn-outline">+ Add Break</button>
      </div>

      <div className="admin-card overflow-x-auto">
        <table className="admin-table">
          <thead><tr><th>#</th><th>Gender</th><th>Event</th><th>Age</th><th>Format</th><th>Day</th><th>Session</th><th>Actions</th></tr></thead>
          <tbody>
            {newEvent && <EventForm evt={newEvent} onSave={saveEvent} onCancel={() => setNewEvent(null)} />}
            {filtered.map(e => editing === e.id ? (
              <EventForm key={e.id} evt={e} onSave={saveEvent} onCancel={() => setEditing(null)} />
            ) : (
              <tr key={e.id} className={e.is_break ? 'bg-amber-50' : ''}>
                <td className="font-bold">{e.is_break ? '—' : e.event_number}</td>
                <td>{e.gender}</td>
                <td>{e.is_break ? <em className="text-amber-600">{e.break_label}</em> : e.event_name}</td>
                <td>{e.age_group}</td>
                <td className="text-xs">{e.format?.replace('_', ' ')}</td>
                <td>{e.day}</td>
                <td>{e.session}</td>
                <td>
                  <div className="flex gap-1">
                    <button onClick={() => setEditing(e.id)} className="text-xs text-blue-600 hover:underline cursor-pointer bg-transparent border-none">Edit</button>
                    <button onClick={() => deleteEvent(e.id)} className="text-xs text-red-600 hover:underline cursor-pointer bg-transparent border-none">Del</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  )
}
