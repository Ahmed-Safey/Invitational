import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useSite } from '../../lib/SiteContext'
import AdminLayout from '../../components/admin/AdminLayout'
import toast from 'react-hot-toast'

export default function ProgramsAdmin() {
  const { refetch, seasons } = useSite()
  const [programs, setPrograms] = useState([])

  const load = async () => {
    const { data } = await supabase.from('programs').select('*').order('season_slug').order('program_type')
    setPrograms(data || [])
  }
  useEffect(() => { load() }, [])

  const saveProgram = async (p) => {
    const { error } = await supabase.from('programs').update({
      google_drive_url: p.google_drive_url, is_published: p.is_published
    }).eq('id', p.id)
    if (error) toast.error(error.message)
    else { toast.success('Program updated'); load() }
  }

  const labels = { psych_sheet: 'Psych Sheets', heat_sheet: 'Heat Sheets', program_booklet: 'Program Booklet', entry_file: 'Entry File (.cl2)' }

  const content = (
    <div>
      {seasons.map(s => (
        <div key={s.slug} className="mb-8">
          <h3 className="font-bold text-gray-900 mb-3">{s.label} {s.is_current && <span className="status-active ml-2">Active</span>}</h3>
          <div className="space-y-3">
            {programs.filter(p => p.season_slug === s.slug).map(p => (
              <div key={p.id} className="admin-card flex items-center gap-4">
                <div className="flex-1">
                  <p className="font-medium text-sm text-gray-900">{labels[p.program_type] || p.label}</p>
                  <input value={p.google_drive_url || ''} onChange={e => setPrograms(programs.map(x => x.id === p.id ? {...x, google_drive_url: e.target.value} : x))}
                    placeholder="Google Drive link..." className="admin-input mt-1" />
                </div>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1 text-sm cursor-pointer">
                    <input type="checkbox" checked={p.is_published} onChange={e => setPrograms(programs.map(x => x.id === p.id ? {...x, is_published: e.target.checked} : x))} />
                    Published
                  </label>
                  <button onClick={() => saveProgram(p)} className="admin-btn text-xs">Save</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Programs</h1>
      <p className="text-sm text-gray-500 mb-6">Manage downloadable documents per season</p>
      {content}
    </AdminLayout>
  )
}
