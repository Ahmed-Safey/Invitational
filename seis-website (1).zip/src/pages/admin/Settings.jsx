import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useSite } from '../../lib/SiteContext'
import AdminLayout from '../../components/admin/AdminLayout'
import toast from 'react-hot-toast'

export default function Settings() {
  const { refetch } = useSite()
  const [form, setForm] = useState({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    supabase.from('site_settings').select('*').single().then(({ data }) => {
      if (data) setForm(data)
    })
  }, [])

  const save = async () => {
    setSaving(true)
    const { id, updated_at, ...updates } = form
    const { error } = await supabase.from('site_settings').update(updates).eq('id', 1)
    if (error) toast.error(error.message)
    else { toast.success('Settings saved'); refetch() }
    setSaving(false)
  }

  const Field = ({ label, field, type = 'text' }) => (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      {type === 'textarea' ? (
        <textarea value={form[field] || ''} onChange={e => setForm({...form, [field]: e.target.value})} className="admin-input h-20" />
      ) : (
        <input type={type} value={form[field] || ''} onChange={e => setForm({...form, [field]: e.target.value})} className="admin-input" />
      )}
    </div>
  )

  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Site Settings</h1>
      <p className="text-sm text-gray-500 mb-6">Global configuration for the website</p>
      <div className="admin-card">
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Identity</h3>
            <Field label="Site Title" field="site_title" />
            <Field label="Site Subtitle" field="site_subtitle" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Hero Badges</h3>
            <Field label="Badge 1" field="hero_badge_1" />
            <Field label="Badge 2" field="hero_badge_2" />
            <Field label="Badge 3" field="hero_badge_3" />
            <Field label="Badge 4" field="hero_badge_4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Entry Fee</h3>
            <Field label="Fee Amount" field="entry_fee_amount" />
            <Field label="Fee Label" field="entry_fee_label" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Contact</h3>
            <Field label="Athletics Director Email" field="contact_email_athletics" type="email" />
            <Field label="Aquatics Department Email" field="contact_email_aquatics" type="email" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Hospitality & Operations</h3>
            <Field label="Hospitality Text" field="hospitality_text" type="textarea" />
            <Field label="Coaches Meeting Text" field="coaches_meeting_text" type="textarea" />
          </div>
        </div>
        <div className="mt-6 pt-4 border-t">
          <button onClick={save} disabled={saving} className="admin-btn">{saving ? 'Saving...' : 'Save Settings'}</button>
        </div>
      </div>
    </AdminLayout>
  )
}
