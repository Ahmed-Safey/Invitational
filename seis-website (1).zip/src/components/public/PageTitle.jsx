import { useEffect } from 'react'

export default function PageTitle({ title }) {
  useEffect(() => {
    document.title = title
      ? `${title.replace(/<[^>]*>/g, '')} | SEIS`
      : 'Swimming Eagles Invitational Series | SEIS'
  }, [title])
  return null
}
